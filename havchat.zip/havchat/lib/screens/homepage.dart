import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chats/chat_screen.dart';
import 'eventscreen/eventspage.dart';
import 'login/loginpage.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({Key? key, required this. userName}) : super(key: key);
  final String? userName;
  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          bottom: TabBar(
            tabs: [
              Tab(text: "Chats",icon: Icon(Icons.chat)),
              Tab(text: "Events",icon: Icon(Icons.calendar_month)),
            ],
          ),
          title: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('HAV Chat',style: Theme.of(context).textTheme.bodyLarge?.apply(fontWeightDelta: 2,fontSizeDelta: 2,color: Colors.grey),),
              Text('${widget.userName}',style: Theme.of(context).textTheme.bodyLarge?.apply(fontWeightDelta: 2,fontSizeDelta: 2),),
              InkWell(
                  onTap: (){
                    showDialog(context: context, builder: (BuildContext context){
                      return Dialog(
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: SizedBox(
                            height: 80,
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start,mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: [
                                    Expanded(
                                      child: InkWell(
                                          onTap: (){
                                            FirebaseAuth.instance.signOut().then((value){
                                              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                                            });
                                          },
                                          child: Container(
                                              padding: EdgeInsets.all(12),
                                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(4),color: Colors.blue),
                                              child: Center(child: Text("Yes")))),
                                    ),
                                    const SizedBox(width: 18,),
                                    Expanded(
                                      child: InkWell(
                                        onTap: (){
                                          Navigator.pop(context);
                                        },
                                        child: Container(
                                            padding: EdgeInsets.all(12),
                                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(4),color: Colors.grey.shade300),
                                            child: Center(child: Text("No"))),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    });
                  },
                  child: Icon(Icons.login))
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            ChatScreen(),
            EventsPageList(),
          ],
        ),
      ),
    );;
  }
}

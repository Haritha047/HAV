import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:havchat/screens/chats/widgets/chatscreen_detailed.dart';
import 'package:shimmer/shimmer.dart';

import '../../Models/user_model.dart';



class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String userId= FirebaseAuth.instance.currentUser?.uid??'';
  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   body: Center(
    //     child: Text("No Chats Yet"),
    //   ),
    // );
    return SafeArea(
      child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('users').snapshots(),
          builder: (context, snap) {
            if(snap.hasData){
              var dataList = snap.data?.docs;
              return dataList?.isEmpty ==true ?
                  Loader():
                ListView.builder(
                itemCount: dataList?.length,
                padding: EdgeInsets.only(
                  left: 15,
                  top: 8,
                  bottom: 10,
                  right: 12,
                ),
                  itemBuilder: (context,index) {
                    UserModel data = UserModel.fromJson(dataList![index].data());
                    return
                      (data.userId==userId)?SizedBox():
                      InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatScreenPage( chatUserid:data.userId??'',userDetails:data)));
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          border: 
                          Border(
                            bottom: BorderSide(color: Colors.grey.withOpacity(0.23))
                          )
                        ),
                        child: Row(
                          children: [
                            DecoratedBox(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.black54,
                                  width: 0.5,
                                ),
                              ),
                              child:  CircleAvatar(
                                radius: 20,
                                child: CachedNetworkImage(
                                  imageUrl: (FirebaseAuth.instance.currentUser?.photoURL)??'',
                                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                                      CircularProgressIndicator(value: downloadProgress.progress),
                                  errorWidget: (context, url, error) => const Icon(CupertinoIcons.person_alt_circle,size: 40,),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    mainAxisAlignment: MainAxisAlignment
                                        .start,
                                    children: [
                                      Text(
                                        data.name??"",
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    );

                  }
                );

            }else{
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          }
        ),

    );
  }
  Widget Loader(){
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade300,
      highlightColor: Colors.grey.shade100,
      child: Row(
        children: [
          DecoratedBox(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey.shade200,
              border: Border.all(
                color: Colors.grey,
                width: 0.5,

              ),
            ),
            child: const CircleAvatar(
              // backgroundImage: AssetImage(
              //     friends[i].user.avatar),
              radius: 20,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment
                  .spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment
                      .start,
                  mainAxisAlignment: MainAxisAlignment
                      .start,
                  children: [


                    Padding(
                        padding: const EdgeInsets.only(
                          bottom: 4,
                        ),
                        child: Container(
                          height: 15,width: 200,
                          color: Colors.grey.shade300,
                        )
                    ),
                    Container(
                      height: 10,width: 150,
                      color: Colors.grey.shade300,
                    ),
                  ],
                ),
                IconButton(
                  onPressed: (){},
                  padding: const EdgeInsets.all(0),
                  splashRadius: 23,
                  icon: const Icon(
                    Icons.more_horiz_rounded,
                    color: Colors.black87,
                    size: 25,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
class ChatUsers {
  String? text;
  String? secondaryText;
  String? image;
  String? time;

  ChatUsers({this.text, this.secondaryText, this.image, this.time});

  ChatUsers.fromJson(Map<String, dynamic> json) {
    text = json['text']??"";
    secondaryText = json['secondaryText']??"";
    image = json['image']??"";
    time = json['time']??"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['text'] = this.text;
    data['secondaryText'] = this.secondaryText;
    data['image'] = this.image;
    data['time'] = this.time;
    return data;
  }
}
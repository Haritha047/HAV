
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:havchat/screens/chats/widgets/pdfviewerfromfile.dart';
import 'package:havchat/screens/chats/widgets/pdfviewerpage.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:chewie/chewie.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:havchat/screens/chats/widgets/prevideoplayer_widget.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io' as io;
import '../../../Models/sendermessagemodel.dart';
import '../../../Models/user_model.dart';
import '../../../cubits/individualchatvideoview/indiavidul_chat_video_view_cubit.dart';
import '../../../cubits/sendmessage_cubit/send_message_cubit.dart';
import '../../../cubits/videoPlayerUpdateCubit/video_player_update_cubit.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'dart:io' ;
import 'package:path_provider/path_provider.dart' as path;
import 'package:pdf/widgets.dart' as pw;
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';

class ChatScreenPage extends StatefulWidget {
  const ChatScreenPage(
      {Key? key, required this.chatUserid, required this.userDetails})
      : super(key: key);
  final UserModel userDetails;
  final String chatUserid;

  @override
  State<ChatScreenPage> createState() => _ChatScreenPageState();
}

class _ChatScreenPageState extends State<ChatScreenPage> {
  TextEditingController messageController = TextEditingController();

  // List<ChatModel> messageList = [];
  final ScrollController _scrollController = ScrollController();

  // final FlutterTts flutterTts=FlutterTts();
  String message = '';
  bool jspeak = false;

  // speak(String msg)async{
  //   await flutterTts.setLanguage("en");
  //   await flutterTts.setPitch(8);
  //   await flutterTts.speak(msg);
  //   await flutterTts.setSpeechRate(15);
  // }

  @override
  void initState() {
    // TODO: implement initState
    // context.read<GetmessagesCubit>().getMessage(widget.chatUserid ?? '');
    // WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
    // addChatMessage();
    // context.read<VoicetotextcubitCubit>().initSpeech();
    // addChatMessage();

    // });
    // addChatMessage();
    Future.delayed(Duration(seconds: 3), () {
      setState(() {});
    });

    super.initState();
    Future.delayed(Duration(milliseconds: 500), () {
      if (_scrollController.positions.isNotEmpty &&
          _scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          curve: Curves.easeOut,
          duration: const Duration(milliseconds: 300),
        );
      }
    });
  }

  void addChatMessage() {
    // setState(() {
    _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    // });
  }

  String? mediaPath;
  bool updated = false;
  String? mediaName;
  bool isVideo = false;

  Future<void> _pickPostImage(bool videova) async {
    final XFile? pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if(pickedFile!=null){
      final extension = pickedFile.path
          .split('.')
          .last
          .toLowerCase();
      if (extension == 'jpg' || extension == 'jpeg' || extension == 'png') {
        setState(() {
          isVideo = false;
          mediaPath = pickedFile.path;
          mediaName = pickedFile.name;
          // for (var element in pickedFile) {
          //   mediaName.add(element.name);
          //   mediaPath.add(element.path);
          //   // if(pickedFile!=null){
          //   //   _initializeVideoPlayer(pickedFile.first.path);
          //   // }
          // }
        });
      } else if (extension=="mp4"){
        setState(() {
          isVideo = true;
          mediaPath = pickedFile.path;
          mediaName = pickedFile.name;
          // _initializeVideoPlayer(pickedFile?.path??'');
          context
              .read<VideoPlayerUpdateCubit>()
              .updatePlayerFromFile(imagePath: pickedFile.path ?? '');
        });
      }else{
        Fluttertoast.showToast(msg: "File format not supported, Please try any other formats");
      }
    }

  }
  Future<void> _pickPostPDF(bool videova) async {
    final List<XFile> pickedFile = await ImagePicker().pickMultiImage();
    if(pickedFile!=null){
      Uint8List? file = await createFile(pickedFile);
      if(file!=null){
        File? scannedDocumentFile=await convertUint8ListToFile(file);

        setState(() {
          isVideo = true;
          mediaPath = scannedDocumentFile.path;
          mediaName = 'document.pdf';
          // _initializeVideoPlayer(pickedFile?.path??'');
        });
      }

    }

  }
  Future<File> convertUint8ListToFile(Uint8List uint8List,) async {
    final tempDir = await path.getTemporaryDirectory();
    final file = File('${tempDir.path}/${"havchat.pdf"}');

    await file.writeAsBytes(uint8List);

    return file;
  }
  Future<Uint8List> createFile(List<XFile> images) async {
    var pdf = pw.Document();

    for(int i=0;i<images.length;i++){
      var file = File(images[i].path);
      final img = pw.MemoryImage(file.readAsBytesSync());
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Center(child: pw.Image(img));
          },
        ),
      );
    }
    //
    // final dir = await getTemporaryDirectory();
    // final file = File('${dir.path}/${userName}.pdf');
    // await file.writeAsBytes(await pdf.save());

    var unitlistPdf= pdf.save();
    print("sdjcnkjsncsncsdncsjn");
    return unitlistPdf;
  }
  DateTime? fromDate;
  Future<void> _pickImageFromCam() async {
    final XFile? pickedFile = await ImagePicker().pickImage(
      imageQuality: 7,
      source: ImageSource.camera,
    );
    setState(() {
      isVideo = false;
      mediaPath = pickedFile?.path;
      mediaName = pickedFile?.name;
    });
  }



  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies

    super.didChangeDependencies();
  }
  bool checkmessageList=false;

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.black12,
                  width: 0.5,
                ),
              ),
              child: CircleAvatar(
                radius: 20,
                child: CachedNetworkImage(
                  fit: BoxFit.fill,
                  imageUrl: widget.userDetails.userProfileImg ?? '',
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      CircularProgressIndicator(
                          value: downloadProgress.progress),
                  errorWidget: (context, url, error) => const Icon(
                    CupertinoIcons.person_alt_circle,
                    size: 40,
                  ),
                ),
              ),
            ),
            const SizedBox(
              width: 12,
            ),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        widget.userDetails.name ?? '',
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
        backgroundColor: Colors.blueAccent.withOpacity(0.2),
      ),
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          // Column(
          //   children: [
          //     Row(mainAxisAlignment: MainAxisAlignment.center,
          //       children: [
          //         Text("Send a Message to  ",style: TextStyle(fontSize: 14),),
          //         Text("${widget.name}",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
          //       ],
          //     ),
          //     const SizedBox(height: 4,),
          //     Container(height: 1,color: Colors.grey,),
          //   ],
          // ),

          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  // .where('receiverId',isEqualTo: userId,)
                  .where('participants', arrayContainsAny: [
                    FirebaseAuth.instance.currentUser?.uid,
                    widget.chatUserid
                  ])
                  .orderBy(
                    "createdAt",
                  )
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<ChatModel> messageList = snapshot.data!.docs.map((e) => ChatModel.fromJson(e.data())).toList();

                  if (messageList.isEmpty) {
                    return const Expanded(
                      child: Center(
                        child: Text('No Chats Yet'),
                      ),
                    );
                  } else {
                    checkSchedule(messageList);
                    // periodic
                    return Expanded(
                      child: ListView.builder(
                          padding: const EdgeInsets.only(
                              left: 8, right: 6, bottom: 12, top: 6),
                          controller: _scrollController,
                          itemCount: messageList.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            var message = messageList[index];
                            bool isMyMessage=message.userId == FirebaseAuth.instance.currentUser?.uid;

                            if ((message.receiverId == widget.chatUserid &&
                                    message.userId == FirebaseAuth.instance.currentUser?.uid) ||
                                (message.userId == widget.chatUserid &&
                                    message.receiverId == FirebaseAuth.instance.currentUser?.uid)) {
                              return (isMyMessage ||  message.scheduledAt == null)? UnconstrainedBox(
                                // constrainedAxis: Axis.horizontal,
                                alignment:
                                    ((message.userId == '${widget.chatUserid}')
                                        ? Alignment.centerLeft
                                        : Alignment.centerRight),
                                child: Container(
                                  padding: EdgeInsets.all(
                                      (message.messageType == 1) ? 8 : 10),
                                  margin: EdgeInsets.only(bottom: 8),
                                  decoration: BoxDecoration(
                                      color: ((message.userId ==
                                              '${widget.chatUserid}')
                                          ? Colors.blueAccent
                                          : Colors.green[300]),
                                      borderRadius: BorderRadius.circular(8)),
                                  // ),
                                  child: Column(
                                    crossAxisAlignment: ((message.userId == '${widget.chatUserid}')
                                        ? CrossAxisAlignment.start
                                        : CrossAxisAlignment.end),
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      (message.messageType == 3)
                                          ?Stack(
                                            children: [
                                              SizedBox(
                                                height: 200,
                                                width: 150,
                                                child: PdfViewerPage(pdfUrl: '${message.message}',),
                                              ),
                                              Positioned(
                                                  top: 2,
                                                  right: 2,
                                                  child: InkWell(
                                                      onTap: (){
                                                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewPdfDOCPage(pdfUrl: '${message.message}', userName: '${widget.userDetails.name}',)));
                                                      },
                                                      child: Icon(Icons.view_in_ar_outlined,size: 18,)))
                                            ],
                                          ):(message.messageType == 1)
                                          ? CachedNetworkImage(
                                              width: 160,
                                              progressIndicatorBuilder:
                                                  (context, url, progress) =>
                                                      Center(
                                                child:
                                                    CircularProgressIndicator(
                                                  value: progress.progress,
                                                ),
                                              ),
                                              imageUrl: message.message ?? '',
                                            )
                                          : (message.messageType == 2)
                                              ? SizedBox(
                                                  width: 200,
                                                  height: 280,
                                                  child: PreVideoPlayerWidget(
                                                      url: message.message))
                                              : (message.message!.length >= 15)
                                                  ? Container(
                                                      constraints:
                                                          const BoxConstraints(
                                                              minWidth: 200,
                                                              maxWidth: 300),
                                                      child: Text(
                                                        "${message.message}",
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontSize: 16,
                                                            color: Colors.white
                                                                .withOpacity(
                                                                    0.95)),
                                                      ))
                                                  : Text(
                                                      "${message.message}",
                                                      softWrap: false,
                                                      maxLines: 1,
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 16,
                                                          color: Colors.white
                                                              .withOpacity(
                                                                  0.95)),
                                                    ),
                                      const SizedBox(
                                        height: 4,
                                      ),
                                      Row(
                                        mainAxisAlignment: ((message.userId ==
                                                '${widget.chatUserid}')
                                            ? MainAxisAlignment.start
                                            : MainAxisAlignment.end),
                                        children: [
                                          Text(
                                            "${DateFormat('hh:mm a').format(message.createdAt!.toDate().toLocal())}",
                                            style: TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 12,
                                                color: Colors.white
                                                    .withOpacity(0.75)),
                                          ),
                                          if(isMyMessage && message.scheduledAt != null)...{
                                            SizedBox(width: 4,),
                                            Icon(Icons.schedule_send,color: Colors.black,size: 18,)
                            }


                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ) :
                              const SizedBox.shrink();
                            } else {
                              return const SizedBox.shrink();
                            }
                          }),
                    );
                  }
                } else {
                  return const Expanded(
                    child: Center(
                      child: Text('No Chats Yet'),
                    ),
                  );
                }
              }),
          Container(
            // color: Colors.grey.withOpacity(0.4),
            child: Padding(
              padding: const EdgeInsets.only(
                  top: 8, bottom: 10.0, left: 12, right: 12),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.withOpacity(0.12))),
                padding: EdgeInsets.all(12),
                child: Column(
                  children: [
                    mediaPath != null
                        ? Stack(
                            children: [
                              (mediaName?.contains('.mp4') ?? false)
                                  ? BlocBuilder<VideoPlayerUpdateCubit,
                                          VideoPlayerUpdateState>(
                                      builder: (context, vidState) {
                                      if (vidState
                                          is VideoPlayerUpdateUpdated) {
                                        print(
                                            " ${vidState.chewieController.videoPlayerController.value.isInitialized}");
                                        return vidState
                                                    .chewieController
                                                    .videoPlayerController
                                                    .value
                                                    .isInitialized
                                            ? Container(
                                                height: 280,
                                                width: 200,
                                                decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: Colors.grey
                                                            .withOpacity(
                                                                0.24))),
                                                child: Chewie(
                                                  controller:
                                                      vidState.chewieController,
                                                ),
                                              )
                                            : SizedBox();
                                      } else {
                                        return Container(
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.grey
                                                      .withOpacity(0.24))),
                                          padding: EdgeInsets.all(100),
                                          child: SizedBox(
                                            height: 26,
                                            width: 26,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 0.8,
                                              color: Colors.orange,
                                            ),
                                          ),
                                        );
                                      }
                                    })
                                  : (mediaName?.contains('.pdf') ?? false)?Stack(
                                    children: [
                                      SizedBox(
                                          height: 184,
                                          width: 160,
                                          child: PdfViewerPageFromFile(pdfUrl: mediaPath??'',)),
                                    Positioned(
                                        top: 2,
                                        left: 2,
                                        child: InkWell(
                                            onTap: (){
                                              Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewPdfDOCPageFromFile(pdfUrl: '${mediaPath}',)));
                                            },
                                            child: Icon(Icons.view_in_ar_outlined,size: 16,)))
                                    ],
                                  ):Image.file(
                                      width: 200,
                                      height: 200,
                                      io.File(mediaPath ?? "")),
                              Positioned(
                                  top: 0,
                                  right: 0,
                                  child: InkWell(
                                      onTap: () {
                                        setState(() {
                                          if ((mediaName?.contains('.mp4') ??
                                              false)) {
                                            context
                                                .read<VideoPlayerUpdateCubit>()
                                                .disposeController();
                                          }
                                          mediaPath = null;
                                          mediaName = '';
                                        });
                                      },
                                      child: Icon(
                                        Icons.cancel,
                                        size: 22,
                                      )))
                            ],
                          )
                        : (fromDate != null)
                        ?  Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Event Set at  ",
                            style:  TextStyle(color: Colors.grey.withOpacity(0.8),fontWeight: FontWeight.w300,fontSize: 12),
                          ),
                          Text("${DateFormat('dd-MM-yyyy kk:mm:a').format(fromDate!)}",
                            style: const TextStyle(color: Colors.black,fontWeight: FontWeight.w400),
                          ),
                          InkWell(
                            onTap: (){
                              setState(() {
                                fromDate = null;
                              });
                            },
                            child: Padding(
                                padding: EdgeInsets.symmetric(horizontal:8 ),
                                child: Icon(Icons.cancel_outlined,color: Colors.black,size: 18,)),
                          )


                        ],
                      ),
                    )
                        : SizedBox(),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                                  height: 48,
                                  child: TextFormField(
                                    onTap: () {
                                      _scrollController.animateTo(
                                          _scrollController
                                              .position.maxScrollExtent,
                                          duration:
                                              Duration(milliseconds: 1000),
                                          curve: Curves.ease);
                                    },
                                    onChanged: (h){
                                      setState(() {

                                      });
                                      // if(messageController.text.isEmpty){
                                      //   if(messageController.text.isNotEmpty){
                                      //     setState(() {
                                      //       isMessageEmpty=false;
                                      //     });
                                      //   }
                                      // }else{
                                      //   if(messageController.text.isEmpty){
                                      //     setState(() {
                                      //       isMessageEmpty=true;
                                      //     });
                                      //   }
                                      // }
                                    },
                                    textAlignVertical: TextAlignVertical.center,
                                    readOnly: false,
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 16),
                                    expands: false,
                                    // enabled: false,
                                    controller: messageController,
                                    decoration: InputDecoration(
                                        suffixIcon: InkWell(
                                            onTap: () async {
                                              if(messageController.text.isEmpty) {
                                                pickerBottomSheet();
                                              }else{
                                                var now = DateTime.now();
                                                final pickedDate= await showDatePicker(
                                                    context: context,
                                                    barrierDismissible: false,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime(1940, 1),
                                                    lastDate: DateTime(DateTime.now().year,DateTime.now().month,DateTime.now().day+2));

                                                //then usually do the future job
                                                if(pickedDate != null ){

                                                  final time= await showTimePicker(
                                                      context: context,
                                                      useRootNavigator: false,
                                                      barrierDismissible: false,
                                                      initialTime: TimeOfDay(hour: DateTime.now().hour, minute: DateTime.now().minute));
                                                  String formattedDate = DateFormat('dd-MM-yyyy').format(pickedDate);
                                                  if(time !=null){
                                                    // print('object');
                                                    // print(DateTime(pickedDate.year,pickedDate.month) == DateTime(now.year,now.month));
                                                    // print((time.minute <= now.minute));
                                                    // print("${time.minute}  ${now.minute}");
                                                    if( DateTime(pickedDate.year,pickedDate.month) == DateTime(now.year,now.month) && (time.hour <= now.hour) && (time.minute < now.minute)) {

                                                      Fluttertoast.showToast(msg: "Please Select Event in Future");
                                                    }else{

                                                      setState(() {
                                                        fromDate = DateTime(pickedDate.year,pickedDate.month,pickedDate.day,time.hour,time.minute);
                                                        // Navigator.pop(context);
                                                      });
                                                    }

                                                  }


                                                }
                                              }
                                            },
                                            child: Icon(
                                              (!messageController.text.isEmpty)? Icons.calendar_month_outlined :Icons.add_a_photo,
                                              color:
                                                  Colors.white.withOpacity(0.85),
                                            )
                                        ),
                                        isDense: false,
                                        enabled: true,
                                        border: const OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(8)),
                                            borderSide: BorderSide(
                                                color: Colors.transparent)),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(8)),
                                            borderSide: BorderSide(
                                                color: Colors.transparent)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(8)),
                                            borderSide: BorderSide(
                                                color: Colors.white
                                                    .withOpacity(0.01))),
                                        filled: true,
                                        contentPadding: EdgeInsets.only(
                                            left: 22, right: 18),
                                        fillColor:
                                            Color.fromRGBO(1, 21, 1, 0.6),
                                        hintStyle: TextStyle(
                                            color:
                                                Colors.white.withOpacity(0.7)),
                                        hintText: "Message"),
                                  ),
                                ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        BlocBuilder<SendMessageCubit, SendMessageState>(
                          builder: (context, state) {
                            if (state is SendMessageSended) {
                              // context.read<GetMessagesCubit>().getSilentMessage(widget.senderuserid,widget.receiverid??'');
                              context.read<SendMessageCubit>().reset();
                            }
                            return InkWell(
                              onTap: () async {
                                String userId =
                                    FirebaseAuth.instance.currentUser?.uid ??
                                        '';
                                if (messageController.text.isNotEmpty) {
                                  // context.read<SendMessageCubit>().sendMessage(userId,widget.chatUserid,messageController.text,0);
                                  if (_scrollController.hasClients) {
                                    _scrollController.animateTo(
                                        _scrollController
                                            .position.maxScrollExtent,
                                        duration: Duration(milliseconds: 800),
                                        curve: Curves.ease);
                                  }
                                  // messageController.text='';
                                  await context
                                      .read<SendMessageCubit>()
                                      .sendMessage(widget.userDetails.name??'',userId, widget.chatUserid,
                                          messageController.text, 0,(fromDate));

                                  messageController.clear();
                                } else {
                                  if (mediaPath != null && mediaPath!.isNotEmpty) {
                                    if (mediaName != null && (mediaName?.contains('.mp4') ?? false)) {
                                      await context
                                          .read<SendMessageCubit>()
                                          .sendMessage(widget.userDetails.name??'',
                                              userId,
                                              widget.chatUserid,
                                              mediaPath ?? '',
                                              2,(fromDate));
                                    } else if(mediaName != null && (mediaName?.contains('.pdf') ?? false)){
                                      await context
                                          .read<SendMessageCubit>()
                                          .sendMessage(widget.userDetails.name??'',
                                              userId,
                                              widget.chatUserid,
                                              mediaPath ?? '',
                                              3,(fromDate));
                                    }else{
                                      await context
                                          .read<SendMessageCubit>()
                                          .sendMessage(widget.userDetails.name??'',
                                              userId,
                                              widget.chatUserid,
                                              mediaPath ?? '',
                                              1,(fromDate));
                                    }

                                    setState(() {
                                      mediaPath = null;
                                    });
                                  }
                                }
                              },
                              child: Container(
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  color: Colors.grey.withOpacity(0.2),
                                ),
                                child: (state is SendMessageLoading)
                                    ? const SizedBox(
                                        height: 16,
                                        width: 16,
                                        child: CircularProgressIndicator(
                                          color: Colors.orange,
                                          strokeWidth: 1,
                                        ),
                                      )
                                    : const Center(
                                        child: Icon(
                                        Icons.send,
                                        size: 22,
                                        color: Colors.grey,
                                      )),
                              ),
                            );
                          },
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),

      // bottomNavigationBar:
    );
  }

  pickerBottomSheet(){
    showModalBottomSheet(
        backgroundColor: Colors.white,
        constraints: BoxConstraints(
          maxHeight:150,
        ),
        context: context,
        builder:
            (BuildContext context) {
          return Container(
            padding: const EdgeInsets.only(
                top: 30,
                bottom: 8,
                right: 26,
                left: 26),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment
                      .spaceAround,
                  children: [
                    InkWell(
                      // decoration: BoxDecoration(
                      //     borderRadius: BorderRadius.circular(6),
                      //   color: Colors.white.withOpacity(0.4),
                      onTap: () {
                        _pickImageFromCam().then(
                                (value) =>
                                Navigator.pop(
                                    context));
                      },
                      // ),

                      child: Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    30),
                                color:
                                Colors.blueAccent),
                            padding:
                            EdgeInsets.all(
                                8),
                            child:
                            Center(
                              child:
                              Icon(
                                Icons
                                    .camera_alt,
                                color:
                                Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height:
                            12,
                          ),
                          Text(
                            "Camera",
                            style: Theme.of(
                                context)
                                .textTheme
                                .bodyMedium
                                ?.apply(
                                fontWeightDelta: 2,
                                color: Colors.black),
                          )
                        ],
                      ),
                    ),
                    InkWell(
                      // decoration: BoxDecoration(
                      //   borderRadius: BorderRadius.circular(6),
                      //   color: Colors.white.withOpacity(0.4),
                      // ),
                      // padding: EdgeInsets.all(12),
                      onTap: () {
                        _pickPostImage(
                            false)
                            .then((value) =>
                            Navigator.pop(
                                context));
                      },
                      child: Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    30),
                                color:
                                Colors.indigo),
                            padding:
                            EdgeInsets.all(
                                8),
                            child:
                            Center(
                              child:
                              Icon(
                                Icons
                                    .image,
                                color:
                                Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height:
                            12,
                          ),
                          Text(
                              "Gallery",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.apply(
                                  fontWeightDelta: 2,
                                  color: Colors.black))
                        ],
                      ),
                    ),
                    InkWell(
                      // decoration: BoxDecoration(
                      //   borderRadius: BorderRadius.circular(6),
                      //   color: Colors.white.withOpacity(0.4),
                      // ),
                      // padding: EdgeInsets.all(12),
                      onTap: () {
                        _pickPostPDF(
                            false)
                            .then((value) =>
                            Navigator.pop(
                                context));
                      },
                      child: Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    30),
                                color:
                                Colors.indigo),
                            padding:
                            EdgeInsets.all(
                                8),
                            child:
                            Center(
                              child:
                              Icon(
                                Icons
                                    .picture_as_pdf,
                                color:
                                Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height:
                            12,
                          ),
                          Text(
                              "Media to PDF",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.apply(
                                  fontWeightDelta: 2,
                                  color: Colors.black))
                        ],
                      ),
                    ),


                  ],
                ),

              ],
            ),
          );
        });
  }
  Timer? timer;

  void checkSchedule(List<ChatModel> messageList) {
    timer=Timer.periodic(Duration(seconds: 1), (timer) {
      var now = DateTime.now();

      for (var element in messageList) {
        if(element.scheduledAt != null && ((element.scheduledAt!.toDate().isBefore(now)) || (element.scheduledAt!.toDate().isAtSameMomentAs(now))) ){
          var document = FirebaseFirestore.instance.collection('chats').doc(element.messageId);
          document.set({
            "scheduledAt":null
          },
              SetOptions(merge: true));
          break;
        }
      }
    });

  }


  @override
  void dispose() {
    messageController.dispose();
    timer?.cancel();
    _scrollController.dispose();
    if (mounted) {
      Future.delayed(Duration.zero, () {
        context.read<VideoPlayerUpdateCubit>().disposeController();
        context.read<IndiavidulChatVideoViewCubit>().disposeController();
      });
    }

    // TODO: implement dispose
    super.dispose();
  }

}

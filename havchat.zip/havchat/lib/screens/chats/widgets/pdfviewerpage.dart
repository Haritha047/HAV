import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
class PdfViewerPage extends StatefulWidget {
  final String pdfUrl;


  PdfViewerPage(
      {required this.pdfUrl,});

  @override
  _PdfViewerPageState createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> with AutomaticKeepAliveClientMixin<PdfViewerPage> {
  @override
  bool get wantKeepAlive => true;

  // bool _isLoading = true;
  // PDFDocument? _scannedDocument;
  //
  // @override
  // void initState() {
  //
  //   super.initState();
  //   _loadPdf();
  // }
  //
  // void _loadPdf() async {
  //   _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
  //   // setState(() {
  //     _isLoading = false;
  //   // });
  //   // Use 'doc' to interact with the loaded PDF, if needed.
  // }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 200,

          child: Container(
            child: (widget.pdfUrl == null)
                ? const Text("No data")
                :const PDF(autoSpacing: false,fitEachPage: true

            ).cachedFromUrl(placeholder: Loadeing,
              widget.pdfUrl,
              //  placeholder: (double progress) => Center(child: Text('$progress %')),
              // errorWidget: (dynamic error) => Center(child: Text(error.toString())),
            ),
          ),
        ),

      ],
    );
  }
}

class ViewPdfDOCPage extends StatefulWidget {
  const ViewPdfDOCPage({super.key, required this.pdfUrl,required this.userName,});

  final String pdfUrl;
  final String userName;

  @override
  State<ViewPdfDOCPage> createState() => _ViewPdfDOCPageState();
}

class _ViewPdfDOCPageState extends State<ViewPdfDOCPage> {
  // Future<void> _downloadAndOpenPdf() async {
  //   final taskId = await OpenFile.open(widget.pdfUrl, type: "application/pdf");
  //   // Optionally, you can use the taskId to monitor the download progress or handle any error during the download.
  // }
  // PDFDocument? _scannedDocument;
  //
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   _loadPdf();
  //   super.initState();
  //
  // }
  //
  // void _loadPdf() async {
  //   _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
  //   // setState(() {
  //
  //   // });
  //   // Use 'doc' to interact with the loaded PDF, if needed.
  // }
  bool isdownloaded=false;


  @override
  Widget build(BuildContext context) {
    double screenheight =MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.userName} Document"),
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height *0.75,
            width: MediaQuery.of(context).size.width,
            child:  (widget.pdfUrl == null)
                ? const Text("No data")
                : const PDF(pageSnap: true,
              pageFling: true,
              fitEachPage: true,
              enableSwipe: true,
              preventLinkNavigation: true,
              swipeHorizontal: true,

            ).cachedFromUrl(placeholder: Loadeing,
              widget.pdfUrl,
              //  placeholder: (double progress) => Center(child: Text('$progress %')),
              errorWidget: (dynamic error) => Center(child: Text(error.toString())),
            ),
            // PDFViewer(
            //             document: _scannedDocument!,
            //           ),
          ),

        ],
      ),
    );
  }
}

Widget Loadeing(double precess)=> const Center(child: SizedBox( width: 24,height: 24,child: Icon(Icons.picture_as_pdf_sharp,size: 20,)));

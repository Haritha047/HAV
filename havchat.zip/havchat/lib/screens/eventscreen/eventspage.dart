import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../Models/sendermessagemodel.dart';
import '../chats/widgets/prevideoplayer_widget.dart';
class EventsPageList extends StatefulWidget {
  const EventsPageList({Key? key}) : super(key: key);

  @override
  State<EventsPageList> createState() => _EventsPageListState();
}

class _EventsPageListState extends State<EventsPageList> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('chats')
        // .where('receiverId',isEqualTo: userId,)
            .orderBy(
          "createdAt",
        )
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<ChatModel> messageList = snapshot.data!.docs.map((e) => ChatModel.fromJson(e.data())).toList();

            if (messageList.isEmpty) {
              return const Expanded(
                child: Center(
                  child: Text('No Chats Yet'),
                ),
              );
            } else {
              // periodic
              return ListView.builder(
                  padding: const EdgeInsets.only(
                      left: 8, right: 6, bottom: 12, top: 12),
                  // controller: _scrollController,
                  itemCount: messageList.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    var message = messageList[index];
                    bool isMyMessage=message.userId == FirebaseAuth.instance.currentUser?.uid;

                      return  (message.scheduledAt!=null)?UnconstrainedBox(
                        // constrainedAxis: Axis.horizontal,
                        alignment: Alignment.topRight,
                        child: Container(
                          padding: EdgeInsets.all(
                              8),
                          margin: EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(2),
                          border: Border.all(color: Colors.grey)),
                          // ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              (message.messageType == 1)
                                  ? CachedNetworkImage(
                                width: 160,
                                progressIndicatorBuilder:
                                    (context, url, progress) =>
                                    Center(
                                      child:
                                      CircularProgressIndicator(
                                        value: progress.progress,
                                      ),
                                    ),
                                imageUrl: message.message ?? '',
                              )
                                  : (message.messageType == 2)
                                  ? SizedBox(
                                  width: 200,
                                  height: 280,
                                  child: PreVideoPlayerWidget(
                                      url: message.message))
                                  : (message.message!.length >= 15)
                                  ? Container(
                                  constraints:
                                  const BoxConstraints(
                                      minWidth: 200,
                                      maxWidth: 300),
                                  child: Text(
                                    "${message.message}",
                                    style: TextStyle(
                                        fontWeight:
                                        FontWeight.w600,
                                        fontSize: 16,
                                        color: Colors.black
                                            .withOpacity(
                                            0.95)),
                                  ))
                                  : Text(
                                "${message.message}",
                                softWrap: false,
                                maxLines: 1,
                                style: TextStyle(
                                    fontWeight:
                                    FontWeight.w600,
                                    fontSize: 16,
                                    color: Colors.black
                                        .withOpacity(
                                        0.95)),
                              ),
                              const SizedBox(
                                height: 4,
                              ),
                              Row(
                                mainAxisAlignment:  MainAxisAlignment.end,
                                children: [
                                  Text(
                                    "${DateFormat('hh:mm a').format(message.scheduledAt!.toDate().toLocal())}",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12,
                                        color: Colors.black
                                            .withOpacity(0.75)),
                                  ),
                                  if(isMyMessage && message.scheduledAt != null)...{
                                    SizedBox(width: 4,),
                                    Icon(Icons.schedule_send,color: Colors.black,size: 10,)
                                  }


                                ],
                              ),
                              Row(
                                mainAxisAlignment:  MainAxisAlignment.end,
                                children: [
                                  Text(
                                    "Send to : ",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12,
                                        color: Colors.black
                                            .withOpacity(0.75)),
                                  ), Text(
                                    "${message.receiverName}",
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                        color: Colors.black
                                            .withOpacity(0.75)),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:  MainAxisAlignment.end,
                                children: [
                                  Text(
                                    "created At : ${DateFormat('hh:mm a').format(message.createdAt!.toDate().toLocal())}",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12,
                                        color: Colors.black
                                            .withOpacity(0.75)),
                                  ),
                                ],
                              ),

                            ],
                          ),
                        ),
                      ): SizedBox();

                  });
            }
          } else {
            return const Expanded(
              child: Center(
                child: Text('No Chats Yet'),
              ),
            );
          }
        });
  }
}

import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'dart:io' as io;
part 'send_message_state.dart';

class SendMessageCubit extends Cubit<SendMessageState> {
  SendMessageCubit() : super(SendMessageInitial());


  Future<bool> sendMessage(String receiverName ,String senderId ,String? receiverId ,String message,int messageType,DateTime? scheduledDate)async{

    try {
      emit(SendMessageLoading());
      if(messageType==0){
        bool success = await sendMessag(receiverName:receiverName,userId: senderId, msgReceiverId: receiverId??'', message: message,messageType:messageType,scheduledDate:scheduledDate);
        if(success){
          emit(SendMessageSended());
          return success;
        }else{
          emit(SendMessageFailed());
          Fluttertoast.showToast(msg: "Unable to send Message");
          return success;
        }
      }else{
        if(message!=""){
          String path="${FirebaseAuth.instance.currentUser!
              .uid}/${DateTime.now()
              .toString()}${message
              .split('/')
              .last}";
          Reference storageReference = FirebaseStorage
              .instance.ref().child(
              path);

          UploadTask uploadTask = storageReference.putFile(
              io.File(message));

          await uploadTask.whenComplete(() =>
              print("Image uploaded"));

          String url = await storageReference
              .getDownloadURL();

          bool success = await sendMessag(receiverName:receiverName,userId: senderId, msgReceiverId: receiverId??'', message: url,messageType:messageType, scheduledDate: scheduledDate);
          if(success){
            emit(SendMessageSended());
            return success;
          }else{
            emit(SendMessageFailed());
            Fluttertoast.showToast(msg: "Unable to send Message");
            return success;
          }
        }else{
          return false;
        }

      }

      // var collection = FirebaseFirestore.instance.collection('users').doc(senderId);
      // collection.collection("sendMessage").doc(receiverId).set({
      //   "sendMessages":FieldValue.arrayUnion([{
      //     "date":"${DateTime.now()}",
      //     "senderId": senderId,
      //     "Message": message
      //   }])
      // },SetOptions(merge : true)).then((value) =>{
      // });
      // var recollection = FirebaseFirestore.instance.collection('users').doc(receiverId);
      // recollection.collection("sendMessage").doc(senderId).set({
      //   "sendMessages":FieldValue.arrayUnion([{
      //     "date":"${DateTime.now()}",
      //     "senderId": senderId,
      //     "Message": message
      //   }])
      // },SetOptions(merge : true)).then((value) {

      // });

    }catch(e){
      print("Eroorro $e");
      emit(SendMessageFailed());
      Fluttertoast.showToast(msg: "Unable to send Message");
      return false;
    }

  }
  void reset(){
    emit(SendMessageInitial());
  }

  static Future<bool> sendMessag({
    required String userId,
    required String msgReceiverId,
    required String message,
    required String receiverName,
    required int messageType, required DateTime? scheduledDate,
  })async{
    bool success=false;

    var document = FirebaseFirestore.instance.collection('chats').doc();

    // var receiverDocument = FirebaseFirestore.instance.collection('users').doc(userId).collection('Messages').doc(msgReceiverId);
    await document.set({
      "userId":userId,
      "receiverId":msgReceiverId,
      "participants":[userId,msgReceiverId],
      // 0  Message
      // 1  Image
      "message":message,
      "messageId":document.id,
      "receiverName":receiverName,
      "messageType":messageType,
      "createdAt":Timestamp.now(),
      "scheduledAt":(scheduledDate != null)?Timestamp.fromDate(scheduledDate):null,
    },SetOptions(merge: true)).then((value) {
      success= true;
      // Fluttertoast.showToast(msg: "Message Added Successfully",backgroundColor: Colors.green);
    }).onError((error, stackTrace) {
      print("sldcnsjcnskdjc ${error}");
      success= false;
    });

    // if(success){
    //   if(receiverUserId!=userId){
    //     sendNotification(message:"${FirebaseAuth.instance.currentUser?.displayName??'User'}_ Commented on Your Post" ,senderUserId:userId ,receiverId: receiverUserId,notificationType: 3);
    //   }

    // }

    return success;

  }
}

import 'package:cloud_firestore/cloud_firestore.dart';

class ChatModel {
  String? userId;
  String? docId;
  String? receiverId;
  String? message;
  String? messageId;
  String? receiverName;
  int? messageType;
  Timestamp? createdAt;
  Timestamp? scheduledAt;

  ChatModel(
      {this.userId,
        this.receiverId,
        this.message,
        this.messageId,
        this.receiverName,
        this.messageType,
        this.scheduledAt,
        this.createdAt});

  ChatModel.fromJson(Map<String, dynamic> json) {
    userId = json['userId'];
    receiverId = json['receiverId'];
    scheduledAt = json['scheduledAt'];
    message = json['message'];
    messageId = json['messageId'];
    receiverName = json['receiverName'];
    messageType = json['messageType'];
    createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['userId'] = userId;
    data['receiverId'] = receiverId;
    data['message'] = message;
    data['messageId'] = messageId;
    data['receiverName'] = receiverName;
    data['scheduledAt'] = scheduledAt;
    data['messageType'] = messageType;
    data['createdAt'] = createdAt;
    return data;
  }
}